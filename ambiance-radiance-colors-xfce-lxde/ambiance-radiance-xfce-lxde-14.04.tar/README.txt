====================================WELCOME=============================================================================================
Ambiance & Radiance Themes for XFCE/LXDE. Version 14.04 (Based on latest theme from Ubuntu 14.04) 
NEW FOR 2014! YAY!
A refined and tested port of Ambiance/Radiance themes for the XFCE/LXDE desktops.
Brought to you by: The RAVEfinity Project, Jared Sot. (www.ravefinity.com) , (Formally: www.iravefuzion.blogspot.com)

This Version (14.04) Requires: Gnome/Gtk 3.6 and Newer. EG. Ubuntu 14.04 and newer only... (Distros from April 2014+)

Ubuntu 13.10, 13.04, 12.10 Are NOT SUPPORTED.

This version (14.04) WILL NOT WORK on Ubuntu 13.10 Gnome/GTK 3.2 or lower.
If you would like to use this theme on Ubuntu 12.04,11.10 Please download the other version of this theme, at our site above.

Please note that Ubuntu 13.10, 13.04, 12.10 Are NOT SUPPORTED by any of our themes, sorry :(
14.04+ Only.

----------------------------------------------------------------------------------------------------------------------------------------

This "port" is not by the offical Ambiance/Radiance team, If you like it then give them the credit, If you hate it, blame us! and submit a fix! :)
however we use the latest stable code from their theme modified only sligtly to work on the XFCE/LXDE desktops.

Ambiance&Radiance Theme for XFCE/LXDE (This is not by the offical Ambiance/Radiance team)
Now you can easily have the unified experience of Ambiance/Radiance themes on LXDE and Openbox desktops.
Includes both: Ambiance & Radiance GTK2&3 Widget and Window border themes.
* Build to work with GTK3! Other Xfce or LXDE themes that don't support GTK3 yet look like Win95(TM) when running gtk3 apps! This theme won't do that!
* Installs as a sperate theme from the main Ambiance/Radiance, for use with XFCE/LXDE only. (please use offical Ambiance/Radiance for Gnome/Unity)

Ambiance&Radiance Theme for XFCE/LXDE.  Aims to be a complete and accurate port of the Ambiance/Radiance Themes for XFCE/LXDE. We have made great strides to make sure it is accurate and complete. It usees the offical Ambiance/Radiance code modified only sligtly to work on XFCE/LXDE desktops. And *ports of* the offical window borders for XFCE (XFWM4) and LXDE (Openbox) in both Ambiance/Radiance flavors. We have updated and made small fixes to the window border themes as well as totally implemented the Radiance on top of XFCE (XFWM4) and LXDE (Openbox) (Not previously available). You will find this theme is probably the most complete package out there to easily have the unified experiacne of Ambiance/Radiance on the LXDE and Openbox since out of the box that theme doesn't really support such desktops.

Brought to you by(Based on):

RAVEfinity (C) 2011-2014+ RAVEfinty, (Jared Sot.) (www.ravefinity.blogspot.com)
We brought all the peices together, We applied and made ALOT of fixes , And we now mantain and devlop the XFCE, LXDE and Openbox Ambiance/Radiance themes. We have also updated the GTK theme to work on XFCE/LXDE. And made this a unified package.

(Based on stock Ambiance/Radiance, We modify as little as possible to make it work on XFCE/LXDE & Openbox.)
Ambiance/Radiance Themes Designed and created By: Kenneth Wimer, James Schriver, Andrea Cimitan (C) 2010-2011 GPL Canonicol LTD.

Primary (Debian/Ubuntu) Software packaging and autobuild launchpad scripts and other help By: Dr. Amr Osman

Lots of Patches, Fixes & Enhancements For Xfce,Lxde and Openbox Namely "Add Widget Fix" and "Overall" Panel Fix.
By: Benoit Thibaud (C) 2012 GPL 

(Originol Openbox Border Based On (Note: we now devlop and mantain this as separate updated "fork" that your useing.)
Ambiance Openbox (Window Borders) By: David Barr (C) 2010 GPL. (http://david.chalkskeletons.com/)*We use the originol and,then ported Radicane based on this.

(Originol XFCE Border Based On (Note: we now devlop and mantain this as separate updated "fork" that your useing.)
Ambiance for XFCE(Window Borders) By: p0ng (C) 2010 GPL  (http://www.p0ng.com.br)*We have applied fixes and ported Radicane based on this.

========= QUICK NOTES==============================================================================

This theme was built to be a independent package that allows you to use the Ambiance & Radiance Themes on XFCE/LXDE, It does this by being a seperate theme completely called Ambiance-XFCE/LXDE, Radiance-XFCE/LXDE. It does not motify your stock Ambiance & Radiance. We reccomend you use it on XFCE/LXDE only. And Use the offical Ambiance & Radiance Themes for Gnome and Unity.

Thats being said just install and activate it in XFCE or LXDE as follows (remember to select Ambiance-XFCE/LXDE, Radiance-XFCE/LXDE and not the stock version!)

(!) Always back up your data and use thease instructions at own risk! its not ours nor our contributors falt if anything goes wrong.
We have taken great strides to provide clear concise and safe instructions! But as always Do This at your own risk ! No Warranty!

======================How to Install/Use==============================================================
------------------------------------------------------------------------------------------------------------------------------------------------------------
(!) Due to permission issues in the GTK Theme System. You may not see the theme properly in root based (Sudo) applications you run from your normal user account if you install the theme in your home folder (/home/YourName/.Themes ) to Avoid/Fix this. Consider installing the Theme System Wide (See bellow) and it will work everywhere!
------------------------------------------------------------------------------------------------------------------------------------------------------------
Install The Theme. *System Wide* -The Recommended Method!
(Note: this Method requires Root or SUDO privileges)

(!) If you have, Gnome Fallback, Mate, XFCE,LXDE,Openbox or Unity Gen Do this! 

Overview of what we need to do:
(To Intsall Ambiance&Radiance-Xfce-LXDE, You Simply Extract the complete package you just downloaded the "Ambiance&Radiance-XfceLXDE.tar.gz" (Folders and all)
to the themes folder for your entire system..."/usr/share/themes/")

Install The Ambiance&Radiance-XfceLXDE Theme:

1.) Open a terminal and type: sudo file-roller (Then type your password when asked)
-Fedora/Redhat Users Without sudo, type: "su -c file-roller" (Then type the root password)

4.) Now You will see the File Roller Archiver application...

Click "File -> Open" Then Browse for the package you just downloaded: "Ambiance&Radiance-XfceLXDE". Then click open.

5.) Once You've opened the "Ambiance&Radiance-XfceLXDE" Tar file, 

Select "Extract". Then Browse to the fallowing folder:"/usr/share/themes/" Then click ok!

6.)The Ambiance&Radiance-XfceLXDE Theme Should now be installed! Now all you must do is select the Ambiance-XfceLXDE or Radiance-XfceLXDE theme VIA your desktops theme manager!

Please Note: You may have to select both the GTK Widget Theme , And Metatcity , XFCEWM & Openbox Window themes separately depending on what desktop your using!
----------------------------------------------------------------------------------------------------------------------------------------------------------- 
(Manually Install The Theme.  *For Your User Account Only*)
To install The Theme for *your user account only*, Fallow these steps, They should work on any GTK2&3 *nix desktop.

1.) Click to Open Up the package file you just downloaded... "Ambiance&Radiance-XfceLXDE.tar.gz"

2.) Once Open, Click the "Extract" Button... Then Browse to: /Home/YourUserName/.Themes

(!)To see the folder (it's a hidden one!) press ctrl+h in this file browser window to view hidden folders. the folder we want to install it in is ".themes" in your home directory. 

3.) Extract the complete package "Ambiance&Radiance-XfceLXDE.tar.gz" file (Folders and all)
to the ".themes" folder in your home directory.

4.) Select it VIA your Theme Manager! see bellow.

(!) This will install the icon theme for the current user only , Evey user will have to do this on there own!, Thats why we recommend the system wide method
------------------------------------------------------------------------------------------------------------------------------------------------------------ 

-On XFCE Desktops Do this to use theme-


1.) Click On The "XFCE Menu".  (Should be On the far left of either the top or bottom of your desktop.)

2.) Click On The "Settings Menu"  Then --> "XFCE Settings Manager"

3.) Now Click The "Appearance" Category.

4.) Now Select Your Desired Version, Ambiance-XfceLXDE or Radiance-XfceLXDE theme from the List!, In the "Style" tab.

5.) Now Go back by clicking the  "<-- Overview" (Back Button)  And select the "Window Manager" Category

6.) Now Select Your Desired Version of Ambiance-XfceLXDE or Radiance-XfceLXDE theme from the List!, In the "Style" Tab Of the "Window Manager" Category.

7.) Once Done you may click Close ! :) 


(!) In case XFCE Settings Manager is not Installed (It really should be, because it's pretty cool), You can also get to the same locations above VIA Clicking:

 "XFCE Menu --> Settings Menu" --> "Appearance"      (then See Step 4)

 "XFCE Menu --> Settings Menu" --> "Window Manager"  (then See step 6)

(!) Note you may also want to enable the Ubuntu Mono Icon theme (Light or Drak depending on what there your useing) from the icon style tab.

Thats All!
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-On LXDE Desktops Do this to use theme-

1.) Click On the "Start" Icon (The Circular Icon in the Taskbar/Panel in far left of your screen.) 

2.) Select The "Preferences Menu", Then --> "Customize Look and Feel" Menu Item

3.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In the: "Widget" Tab And Click Apply.

Lastly! To Select the Window Borders on LXDE...
4.) Select The "Preferences Menu", Then --> "Openbox Configuration Manager" Menu Item

5.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In The "Openbox Configuration Manager" Themes Tab.

!) Note you may also want to enable the Ubuntu Mono Icon theme (Light or Drak depending on what there your useing) from the icon style tab.

Thats All!

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-On OpenBox Desktops Do This-

Openbox, out of the box does not have a GUI fronted option to switch your GTK-Theme and Icons.
However most prebuilt openbox desktops Such as CrunchBang(Openbox Edition), ETC will will include the lxappearance utility. If you don't have this utility you should install it via your package manager.

Once it is installed, You can launch it via the command line or run command dialog...

1.) Right click on your Openbox desktop and Find the "lxappearance" Application in your openbox menu. Or Open a terminal or run command prompt and type: lxappearance (and press  enter)

2.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In the: "Widget" Tab And Click Apply.

3.) Now Open your Openbox menu by right clicking and find the obconf (Openbox Configuration Manager) Application.

4.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In The "Openbox Configuration Manager" Themes Tab. 

Thats All!
-------------------------------------------------------------------------------------------------------------------------------------------------------------

No Furthers tweask are need to make XFCE & LXDE work in Ubuntu 14.04!
Panel hack not needed cool!

---------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------
Thats All! - Written by Jared Sot. (Please forgive any spelling errors. It's a lot of work to provide complete and up to date documentation. )
---------------------------------------------------------------------------------------------------------------------------------------------------------
